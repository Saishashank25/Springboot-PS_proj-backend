/***************************************************************************************************
 * Initialize the $localize global for i18n support.
 */
/*import '@angular/localize/init';*/

/***************************************************************************************************
 * Zone JS is required by Angular.
 */
import 'zone.js';  // Included with Angular CLI.
