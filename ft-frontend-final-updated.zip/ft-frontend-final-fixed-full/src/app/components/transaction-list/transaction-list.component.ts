import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransactionService } from '../../services/transaction.service';

@Component({
  selector: 'app-transaction-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './transaction-list.component.html',
  styleUrls: ['./transaction-list.component.css']
})
export class TransactionListComponent implements OnInit {
  transactions: any[] = [];

  constructor(private txService: TransactionService) {}

  ngOnInit() {
  this.txService.getAll().subscribe({
    next: txs => this.transactions = txs,
    error: err => {
      console.error("Backend call failed:", err);
      // Use placeholder data
      this.transactions = [
        { id: 1, type: 'INCOME', category: 'Salary', amount: 1000, date: '2025-06-05', description: 'Sample transaction' }
      ];
    }
  });
}
}
