import { Component } from '@angular/core';
import { AddTransactionComponent } from '../add-transaction/add-transaction.component';
import { TransactionListComponent } from '../transaction-list/transaction-list.component';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../../services/auth.service';
import { TransactionService } from '../../services/transaction.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    AddTransactionComponent,
    TransactionListComponent,
    MatButtonModule
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  constructor(
    public auth: AuthService,
    public txService: TransactionService
  ) {}

  logout() {
    this.auth.logout();
  }

  importBank() {
    this.txService.importBank().subscribe({
      next: msg => alert('Imported!'),
      error: err => alert('Import failed')
    });
  }
}
