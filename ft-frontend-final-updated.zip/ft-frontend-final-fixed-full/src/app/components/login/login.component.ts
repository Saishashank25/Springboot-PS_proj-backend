import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    RouterModule
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email = '';
  password = '';

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
  this.authService.login({ username: this.email, password: this.password }).subscribe({
    next: (res) => {
      console.log('Login response:', res);
      localStorage.setItem('token', res.token);
      this.router.navigate(['/dashboard']); // adjust field if needed
      console.log('Token stored:', localStorage.getItem('token'));
      setTimeout(() => {
        this.router.navigate(['/dashboard']);
      }, 100);
    },
    error: (err) => {
      console.error('Login failed:', err);
    }
  });
}

}
