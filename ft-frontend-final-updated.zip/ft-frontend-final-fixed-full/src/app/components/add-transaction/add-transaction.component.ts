import { Component } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule } from '@angular/common';
import { TransactionService } from '../../services/transaction.service';

@Component({
  selector: 'app-add-transaction',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule
  ],
  templateUrl: './add-transaction.component.html',
  styleUrls: ['./add-transaction.component.css']
})
export class AddTransactionComponent {
  txForm: any;
  categories = ['Salary', 'Food', 'Rent', 'Travel', 'Misc'];

  constructor(private fb: FormBuilder, private txService: TransactionService) {
    this.txForm = this.fb.group({
      type: ['INCOME', Validators.required],
      category: ['', Validators.required],
      amount: [0, [Validators.required, Validators.min(1)]],
      date: [new Date().toISOString().substring(0,10), Validators.required],
      description: ['']
    });
  }

  onSubmit() {
    if (this.txForm.valid) {
      this.txService.addTransaction(this.txForm.value!).subscribe();
      this.txForm.reset({ type: 'INCOME', amount: 0, date: new Date().toISOString().substring(0,10) });
    }
  }
}
