// This file is intentionally left blank. Required by Angular for type checking.
