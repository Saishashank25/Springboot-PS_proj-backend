package com.finance.tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceTrackerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
