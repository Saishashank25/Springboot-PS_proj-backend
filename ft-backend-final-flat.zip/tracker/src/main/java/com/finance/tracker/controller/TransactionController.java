package com.finance.tracker.controller;

import com.finance.tracker.model.Transaction;
import com.finance.tracker.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    // Get all transactions for the current user
    @GetMapping
    public List<Transaction> getAllTransactions(Principal principal) {
        return transactionService.getTransactionsForUser(principal.getName());
    }

    // Add new transaction for current user
    @PostMapping
    public ResponseEntity<Transaction> addTransaction(@RequestBody Transaction transaction, Principal principal) {
        Transaction created = transactionService.addTransactionForUser(transaction, principal.getName());
        return ResponseEntity.ok(created);
    }

    // Update transaction (only if owned by user)
    @PutMapping("/{id}")
    public ResponseEntity<?> updateTransaction(@PathVariable Long id, @RequestBody Transaction transaction, Principal principal) {
        Transaction updated = transactionService.updateTransactionForUser(id, transaction, principal.getName());
        if (updated != null) return ResponseEntity.ok(updated);
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("You cannot update this transaction.");
    }

    // Delete transaction (only if owned by user)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTransaction(@PathVariable Long id, Principal principal) {
        boolean deleted = transactionService.deleteTransactionForUser(id, principal.getName());
        if (deleted) return ResponseEntity.ok().build();
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("You cannot delete this transaction.");
    }
}
