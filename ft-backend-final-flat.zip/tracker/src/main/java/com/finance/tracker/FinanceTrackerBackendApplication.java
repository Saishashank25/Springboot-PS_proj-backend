package com.finance.tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanceTrackerBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanceTrackerBackendApplication.class, args);
	}

}
