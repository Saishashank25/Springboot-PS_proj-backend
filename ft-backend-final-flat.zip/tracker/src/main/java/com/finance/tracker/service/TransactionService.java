package com.finance.tracker.service;

import com.finance.tracker.model.Transaction;
import com.finance.tracker.model.User;
import com.finance.tracker.repository.TransactionRepository;
import com.finance.tracker.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private UserRepository userRepository;

    // Get all transactions for a user
    public List<Transaction> getTransactionsForUser(String username) {
        User user = userRepository.findByUsername(username);
        return transactionRepository.findByUser(user);
    }

    // Add a transaction for a user
    public Transaction addTransactionForUser(Transaction transaction, String username) {
        User user = userRepository.findByUsername(username);
        transaction.setUser(user);
        return transactionRepository.save(transaction);
    }

    // Update transaction if owned by user
    public Transaction updateTransactionForUser(Long id, Transaction update, String username) {
        Transaction t = transactionRepository.findById(id).orElse(null);
        if (t != null && t.getUser().getUsername().equals(username)) {
            t.setAmount(update.getAmount());
            t.setCategory(update.getCategory());
            t.setDate(update.getDate());
            t.setDescription(update.getDescription());
            return transactionRepository.save(t);
        }
        return null;
    }

    // Delete transaction if owned by user
    public boolean deleteTransactionForUser(Long id, String username) {
        Transaction t = transactionRepository.findById(id).orElse(null);
        if (t != null && t.getUser().getUsername().equals(username)) {
            transactionRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
