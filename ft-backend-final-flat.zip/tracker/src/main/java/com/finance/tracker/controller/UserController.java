package com.finance.tracker.controller;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
public class UserController {

    // Returns the username of the authenticated user
    @GetMapping("/me")
    public String getCurrentUser(Authentication authentication) {
        // `authentication.getName()` returns the username
        return authentication.getName();
    }
}
